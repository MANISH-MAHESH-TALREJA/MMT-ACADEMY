package net.manish.sem05.utils;

public interface OnHomePressedListener {

    void onHomePressed();





}
